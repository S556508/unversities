//
//  Universities.swift
//  Meesala_UniversityApp
//
//  Created by Meesala,Adilakshmi on 4/20/23.
//

import Foundation
struct Universities
{
    var domain = ""
    var list_Array: [UniversityList] = []
}



struct UniversityList
{
    var collegeName = ""
    var collegeImage  = ""
    var collegeInfo  = ""
    
}

let u1 = Universities(domain: "Computer Science", list_Array: [UniversityList(collegeName: "Northwest Missouri State Unversity", collegeImage: "img", collegeInfo: "Northwest Missouri State University is a public university in Maryville, Missouri. It has an enrollment of about 8,505 students. Founded in 1905 as a teachers college, its campus is based on the design for Forest Park at the 1904 St. Louis World's Fair and is the official Missouri State Arboretum"),
    UniversityList(collegeName: "university of central missouri", collegeImage: "UCM", collegeInfo: "The University of Central Missouri is a public university in Warrensburg, Missouri. In 2019, enrollment was 11,229 students from 49 states and 59 countries on its 1,561-acre campus. UCM offers 150 programs of study, including 10 pre-professional programs, 27 areas of teacher certification, and 37 graduate programs"),
   UniversityList(collegeName: "george mason university", collegeImage: "GMU", collegeInfo: "George Mason University is a public research university in Fairfax County, Virginia, with an independent City of Fairfax postal address in the Washington metropolitan area. The university was originally founded in 1949 as a Northern Virginia regional branch of the University of Virginia"),
                                                              
  UniversityList(collegeName: "university of texas at dallas", collegeImage: "UTD", collegeInfo: "The University of Texas at Dallas is a public research university in Richardson, Texas. It is one of the largest public universities in the Dallas area and the northernmost institution of the University of Texas system. It was initially founded in 1961 as a private research arm of Texas Instruments"),UniversityList(collegeName: "university of south florida", collegeImage: "USF", collegeInfo: "The University of South Florida is a public research university with its main campus located in Tampa, Florida, and other campuses in St. Petersburg and Sarasota. It is one of 12 members of the State University System of Florida")])



let u2 = Universities(domain: "Information Technology", list_Array: [UniversityList(collegeName: "university of central florida", collegeImage: "UCF", collegeInfo: "he University of Central Florida is a public research university with its main campus in unincorporated Orange County, Florida. UCF also has nine smaller regional campuses throughout central Florida. It is part of the State University System of Florida"),
    UniversityList(collegeName: "university of south carolina", collegeImage: "USC", collegeInfo: "TThe University of South Carolina is a public research university in Columbia, South Carolina. It is the flagship of the University of South Carolina System and the largest university in the state by enrollment. Its main campus is on over 359 acres in downtown Columbia, close to the South Carolina State House"),
   UniversityList(collegeName: "texas a&m", collegeImage: "TAM", collegeInfo: "Texas A&M University is a public, land-grant, research university in College Station, Texas. It was founded in 1876 and became the flagship institution of the Texas A&M University System in 1948"),
                                                              
  UniversityList(collegeName: "Dallas Baptist University", collegeImage: "DBU", collegeInfo: "DBU seeks to transform students who will transform the world. To this end, we challenge students to love the Lord"),UniversityList(collegeName: "University of Missouri-Kansas City", collegeImage: "UMKC", collegeInfo: "UMKC is the largest comprehensive, fully accredited university in the Kansas City area with award-winning academic programs and a diverse, inclusive campus")])

let u3 = Universities(domain: "Data Science And Analytics", list_Array: [UniversityList(collegeName: "university of central florida", collegeImage: "UCF", collegeInfo: "he University of Central Florida is a public research university with its main campus in unincorporated Orange County, Florida. UCF also has nine smaller regional campuses throughout central Florida. It is part of the State University System of Florida"),
    UniversityList(collegeName: "university of south carolina", collegeImage: "USC", collegeInfo: "TThe University of South Carolina is a public research university in Columbia, South Carolina. It is the flagship of the University of South Carolina System and the largest university in the state by enrollment. Its main campus is on over 359 acres in downtown Columbia, close to the South Carolina State House"),
   UniversityList(collegeName: "texas a&m", collegeImage: "TAM", collegeInfo: "Texas A&M University is a public, land-grant, research university in College Station, Texas. It was founded in 1876 and became the flagship institution of the Texas A&M University System in 1948"),
                                                              
  UniversityList(collegeName: "Dallas Baptist University", collegeImage: "DBU", collegeInfo: "DBU seeks to transform students who will transform the world. To this end, we challenge students to love the Lord"),UniversityList(collegeName: "University of Missouri-Kansas City", collegeImage: "UMKC", collegeInfo: "UMKC is the largest comprehensive, fully accredited university in the Kansas City area with award-winning academic programs and a diverse, inclusive campus")])



let u4 = Universities(domain: "Cyber Security", list_Array: [UniversityList(collegeName: "university of central florida", collegeImage: "UCF", collegeInfo: "he University of Central Florida is a public research university with its main campus in unincorporated Orange County, Florida. UCF also has nine smaller regional campuses throughout central Florida. It is part of the State University System of Florida"),
    UniversityList(collegeName: "university of south carolina", collegeImage: "USC", collegeInfo: "TThe University of South Carolina is a public research university in Columbia, South Carolina. It is the flagship of the University of South Carolina System and the largest university in the state by enrollment. Its main campus is on over 359 acres in downtown Columbia, close to the South Carolina State House"),
   UniversityList(collegeName: "texas a&m", collegeImage: "TAM", collegeInfo: "Texas A&M University is a public, land-grant, research university in College Station, Texas. It was founded in 1876 and became the flagship institution of the Texas A&M University System in 1948"),
                                                              
  UniversityList(collegeName: "Dallas Baptist University", collegeImage: "DBU", collegeInfo: "DBU seeks to transform students who will transform the world. To this end, we challenge students to love the Lord"),UniversityList(collegeName: "University of Missouri-Kansas City", collegeImage: "UMKC", collegeInfo: "UMKC is the largest comprehensive, fully accredited university in the Kansas City area with award-winning academic programs and a diverse, inclusive campus")])



let u5 = Universities(domain: "Machine Learning", list_Array: [UniversityList(collegeName: "university of central florida", collegeImage: "UCF", collegeInfo: "he University of Central Florida is a public research university with its main campus in unincorporated Orange County, Florida. UCF also has nine smaller regional campuses throughout central Florida. It is part of the State University System of Florida"),
    UniversityList(collegeName: "university of south carolina", collegeImage: "USC", collegeInfo: "TThe University of South Carolina is a public research university in Columbia, South Carolina. It is the flagship of the University of South Carolina System and the largest university in the state by enrollment. Its main campus is on over 359 acres in downtown Columbia, close to the South Carolina State House"),
   UniversityList(collegeName: "texas a&m", collegeImage: "TAM", collegeInfo: "Texas A&M University is a public, land-grant, research university in College Station, Texas. It was founded in 1876 and became the flagship institution of the Texas A&M University System in 1948"),
                                                              
  UniversityList(collegeName: "Dallas Baptist University", collegeImage: "DBU", collegeInfo: "DBU seeks to transform students who will transform the world. To this end, we challenge students to love the Lord"),UniversityList(collegeName: "University of Missouri-Kansas City", collegeImage: "UMKC", collegeInfo: "UMKC is the largest comprehensive, fully accredited university in the Kansas City area with award-winning academic programs and a diverse, inclusive campus")])

let universities = [u1,u2,u3,u4,u5]




