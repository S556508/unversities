//
//  UniversityInfoViewController.swift
//  Meesala_UniversityApp
//
//  Created by Meesala,Adilakshmi on 4/20/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {

    @IBOutlet weak var universityImageViewOutlet: UIImageView!
    
    @IBOutlet weak var universityInfoOutlet: UITextView!
    
    @IBOutlet weak var btnol: UIButton!
    
    var uniImage = ""
    
    var uniInfoText = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        btnol.isHidden = false
        universityInfoOutlet.isHidden = true

        // Do any additional setup after loading the view.
    }
    
    @IBAction func showInfoAction(_ sender: UIButton)
    {
        universityInfoOutlet.isHidden = false
        universityInfoOutlet.text! = uniInfoText
    }
    
   override func viewDidAppear(_ animated: Bool) {
//       UIView.animate(withDuration: 0.9)
//       {
//            self.universityImageViewOutlet.frame.origin.x = 70
//
//           self.universityImageViewOutlet.frame.origin.y = 158
      
       super.viewWillAppear(animated)
       universityImageViewOutlet.image = UIImage(named: uniImage)
       universityImageViewOutlet.frame.origin.x = view.bounds.width
       
       UIView.animate(withDuration: 1.5, delay: 0.0, options: .curveEaseInOut, animations: {self.universityImageViewOutlet.frame.origin.x = self.view.bounds.width - self.universityImageViewOutlet.frame.size.width}, completion: nil)
       
       
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
