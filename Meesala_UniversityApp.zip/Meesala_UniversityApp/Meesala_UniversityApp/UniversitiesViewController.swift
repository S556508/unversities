//
//  ViewController.swift
//  Meesala_UniversityApp
//
//  Created by Meesala,Adilakshmi on 4/20/23.
//

import UIKit

class UniversitiesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return universities.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        var domainCell = universitiesTableView.dequeueReusableCell(withIdentifier: "domainCell", for: indexPath)
        //populate a cell with data
        domainCell.textLabel?.text = universities[indexPath.row].domain
        //return cell
        return domainCell
    }
    

    @IBOutlet weak var universitiesTableView: UITableView!
    var universityArray = universities
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        universitiesTableView.delegate = self
        universitiesTableView.dataSource = self
        self.title = "Domains"
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "listsSegue"
        {
            let destination = segue.destination as! UniversityListViewController
            destination.uArray = universityArray[(universitiesTableView.indexPathForSelectedRow?.row)!].list_Array
            
            destination.title = universityArray[(universitiesTableView.indexPathForSelectedRow?.row)!].domain
        }
    }


}

