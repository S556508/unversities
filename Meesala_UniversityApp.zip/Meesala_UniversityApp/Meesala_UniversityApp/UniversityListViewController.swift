//
//  UniversityListViewController.swift
//  Meesala_UniversityApp
//
//  Created by Meesala,Adilakshmi on 4/20/23.
//

import UIKit

class UniversityListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return uArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var uniCell = universityListTableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        
        
                //populate a cell with data
        uniCell.textLabel?.text = uArray[indexPath.row]?.collegeName
        
        
                //return the cell
                return uniCell
    }
    

    @IBOutlet weak var universityListTableView: UITableView!
    var uArray:[UniversityList?] = []
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        universityListTableView.delegate = self
        universityListTableView.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "universityInfoSegue"{
            
            let destination = segue.destination as! UniversityInfoViewController
            
            //send the selected product row
            
            destination.uniImage = uArray[(universityListTableView.indexPathForSelectedRow?.row)!]!.collegeImage
            destination.uniInfoText = uArray[(universityListTableView.indexPathForSelectedRow?.row)!]!.collegeInfo
            destination.title = uArray[(universityListTableView.indexPathForSelectedRow?.row)!]!.collegeName
            
            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
